package com.example.recyclerviewurl;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public  class CustomAdaptor extends RecyclerView.Adapter<CustomAdaptor.ViewHolder> {
    ArrayList<DataItems> dataItems;
    CustomAdaptor( ArrayList<DataItems> dataItems){
        this.dataItems=dataItems;
    }
    private Context context;



    @NonNull
    @Override
    public CustomAdaptor.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_layout,parent,false);
        return new ViewHolder(view);
    }




    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        DataItems objDataItems= dataItems.get(position);
        holder.title.setText(objDataItems.title);
        holder.movieImage.setImageDrawable(holder.movieImage.getContext().getResources().getDrawable(objDataItems.imageId));
//
//        Glide.with(context)
//                .load(objDataItems.imageURL)
//                .into(holder.imageURL);
        holder.year.setText(objDataItems.year);
        holder.genre.setText(objDataItems.genre);
        holder.rating.setText(objDataItems.rating);
    }

    @Override
    public int getItemCount() {
        return dataItems.size();
    }


    class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        ImageView movieImage ;
        TextView year;
        TextView genre;
        TextView rating;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            title=itemView.findViewById(R.id.movie_title);
            movieImage = itemView.findViewById(R.id.movie_image);
            year=itemView.findViewById(R.id.year);
            genre=itemView.findViewById(R.id.movie_genres);
            rating=itemView.findViewById(R.id.movie_rating);


        }
    }



}